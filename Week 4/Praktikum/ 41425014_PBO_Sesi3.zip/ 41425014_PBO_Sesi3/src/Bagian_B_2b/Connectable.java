/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Bagian_B_2b;

/**
 *
 * @author USER
 */
interface Connectable {
    void connectToWifi(String ssid, String ipAddress);
}
